# 8Bit-Mixtape-NEO-Lib

You can simple add this library by unzipping or cloning it to your Adruino libraries folder.

See the instructions here: https://github.com/8BitMixtape/8Bit-Mixtape-NEO/wiki/4_1-Libraries


